<template>
  <div class="header">
    <h1>Form</h1>
  </div>
</template>

<script>
export default {
  name: "Header",
};
</script>


<style>
.header {
  display: flex;
  justify-content: center;
  text-align: center;
}

.header h1 {
  background: black;
  width: 100%;

  color: white;

  margin-top: -4px;
}
</style>