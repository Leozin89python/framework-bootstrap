<template>
  <div class="title">
    <h3>
      Formulário
    </h3>
  </div>
</template>

<script>
export default {
  name:'Title'
}
</script>


<style>
  .title{
    
  }
</style>